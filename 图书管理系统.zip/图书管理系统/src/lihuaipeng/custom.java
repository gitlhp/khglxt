package lihuaipeng;
public class custom {
 private  String khid;
 private  String kuname;
 private  String szdq;
 private  String tel;
 private  String  dqid;
 private  String dqname;
public custom(String khid, String khname, String szdq, String tel,String dqid,
		String dqname) {
	super();
	this.khid = khid;
	this.kuname = kuname;
	this.szdq = szdq;
	this.tel = tel;
	this.dqid = dqid;
	this.dqname = dqname;
}

public custom(String khid, String khname, String szdq, String tel) {
	super();
	this.khid = khid;
	this.kuname = kuname;
	this.szdq = szdq;
	this.tel = tel;
}

public custom(String dqid, String dqname) {
	super();
	this.dqid = dqid;
	this.dqname = dqname;
}

public String getKhid() {
	return khid;
}

public void setKhid(String khid) {
	this.khid = khid;
}

public String getKuname() {
	return kuname;
}

public void setKuname(String kuname) {
	this.kuname = kuname;
}

public String getSzdq() {
	return szdq;
}

public void setSzdq(String szdq) {
	this.szdq = szdq;
}

public String getTel() {
	return tel;
}

public void setTel(String tel) {
	this.tel = tel;
}

public String getDqid() {
	return dqid;
}

public void setDqid(String dqid) {
	this.dqid = dqid;
}

public String getDqname() {
	return dqname;
}

public void setDqname(String dqname) {
	this.dqname = dqname;
}


 
 
}
