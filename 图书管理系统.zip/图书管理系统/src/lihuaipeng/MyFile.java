package lihuaipeng;

import java.io.FileOutputStream;
import java.io.IOException;

class MyFile{
	public static void saveFile(String dest, String content){//lujing
		try {
			FileOutputStream fout;//�ļ�����ֽ���
			fout = new FileOutputStream(dest, true);//׷����һ��
			byte[] bOut=content.getBytes();//meiciyigezijie ��ʼ�ĵ�ַ
			fout.write(bOut);
			fout.write(13);fout.write(10);//����13\r   10\n
			fout.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	}
}
